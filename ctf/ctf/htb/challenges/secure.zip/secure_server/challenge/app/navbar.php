<div class="rpgui-center" style="position: relative; width: 100%;">
   <a href="/">
      <button type="button" class="rpgui-button" style="width:32%;">
         <p>Home</p>
      </button>
   </a>
   <a href="/about-us.php">
      <button type="button" class="rpgui-button" style="width:32%;">
         <p>About Us</p>
      </button>
   </a>
   <a href="/our-projects.php?project=orion">
      <button type="button" class="rpgui-button" style="width:32%;">
         <p>Our Projects</p>
      </button>
   </a>
</div>